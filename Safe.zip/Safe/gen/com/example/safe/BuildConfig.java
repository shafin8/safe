/** Automatically generated file. DO NOT MODIFY */
package com.example.safe;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}